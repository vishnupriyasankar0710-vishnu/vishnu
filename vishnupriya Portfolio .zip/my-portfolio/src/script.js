// Add skills dynamically

const skills = ["JavaScript", "HTML", "CSS", "Java"];

const skillsList = document.getElementById("skills-list");

skills.forEach(skill => {

    const skillElement = document.createElement("li");

    skillElement.textContent = skill;

    skillsList.appendChild(skillElement);

});

// Add projects dynamically

const projects = [

    { title: "Project 1", description: "This is project 1" },

    { title: "Project 2", description: "This is project 2" },

];

const projectsContainer = document.getElementById("projects-container");

projects.forEach(project => {

    const projectElement = document.createElement("div");

    projectElement.classList.add("project");

    projectElement.innerHTML = `

        <h2>${project.title}</h2>

        <p>${project.description}</p>

    `;

    projectsContainer.appendChild(projectElement);

});